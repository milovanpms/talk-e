*PADS-LIBRARY-PART-TYPES-V9*

DMP1045U-7 SOT96P240X110-3N I ANA 9 1 0 0 0
TIMESTAMP 2026.05.12.13.03.43
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" DMP1045U-7
"Mouser Part Number" 621-DMP1045U-7
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/DMP1045U-7?qs=T%2FOtf55vL7eEKnIWhgMvTQ%3D%3D
"Arrow Part Number" DMP1045U-7
"Arrow Price/Stock" https://www.arrow.com/en/products/dmp1045u-7/diodes-incorporated?utm_currency=USD&region=asia
"Description" P-Channel Enhancement MOSFET SOT-23 Diodes Inc DMP1045U-7 P-channel MOSFET Transistor, 5.2 A, -12 V, 3-Pin SOT23
"Datasheet Link" https://www.diodes.com//assets/Datasheets/DMP1045U.pdf
"Geometry.Height" 1.1mm
GATE 1 3 0
DMP1045U-7
1 0 U G
2 0 U S
3 0 U D

*END*
*REMARK* SamacSys ECAD Model
275755/2057019/2.50/3/2/Integrated Circuit
